import pytesseract
from PIL import Image
import jpholiday
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
import datetime
import re

# 1. OCRで画像からテキスト取得
def extract_text_from_image(image_path):
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img, lang="jpn")
    return text

# 2. テキストから日付・予定抽出（例: 7/15 社内会議）
def parse_events(text):
    # シンプルな日付＋予定抽出例
    pattern = r"(\d{1,2}/\d{1,2})\s*(.+)"
    events = []
    for line in text.split("\n"):
        m = re.match(pattern, line)
        if m:
            month_day = m.group(1)
            title = m.group(2)
            # 年の補完
            year = datetime.datetime.now().year
            try:
                event_date = datetime.datetime.strptime(f"{year}/{month_day}", "%Y/%m/%d")
                events.append({"date": event_date, "title": title})
            except ValueError:
                continue
    return events

# 3. 祝日を除外
def filter_holidays(events):
    return [e for e in events if not jpholiday.is_holiday(e["date"])]

# 4. Googleカレンダー認証
def get_calendar_service():
    SCOPES = ['https://www.googleapis.com/auth/calendar']
    flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
    creds = flow.run_local_server(port=0)
    service = build('calendar', 'v3', credentials=creds)
    return service

# 5. 予定をGoogleカレンダーへ追加
def add_events_to_calendar(events, service, calendar_id='primary'):
    for event in events:
        event_body = {
            'summary': event['title'],
            'start': {'date': event['date'].strftime('%Y-%m-%d')},
            'end': {'date': event['date'].strftime('%Y-%m-%d')},
        }
        service.events().insert(calendarId=calendar_id, body=event_body).execute()
        print(f"Added: {event['title']} on {event['date'].strftime('%Y-%m-%d')}")

if __name__ == "__main__":
    image_path = "sample_schedule.jpg"  # 予定表画像のファイル名
    text = extract_text_from_image(image_path)
    print("OCR結果:", text)
    events = parse_events(text)
    events = filter_holidays(events)
    print("追加予定:", events)

    # GoogleカレンダーAPI認証＆追加
    service = get_calendar_service()
    add_events_to_calendar(events, service)