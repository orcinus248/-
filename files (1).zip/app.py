import os
import pytesseract
from PIL import Image
import jpholiday
from flask import Flask, request, render_template, redirect, url_for, session
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
import datetime
import re
import tempfile

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # セッションに必要。適宜変更
UPLOAD_FOLDER = './uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 画像からOCR
def extract_text(image_path):
    img = Image.open(image_path)
    return pytesseract.image_to_string(img, lang="jpn")

# 予定抽出・全条件フィルタ
def parse_events(text, selected_grade, selected_course, selected_subcourse=None, selected_exam_type=None):
    """
    OCRテキストから予定を抽出し、学年・学科・サブ学科・試験区分でフィルタ
    例: 6/15 3年 海洋 制御 S試験 数学
    """
    pattern = r"(\d{1,2}/\d{1,2})\s*(\d+年)?\s*(海事|海洋|流通)?\s*(制御|機関)?\s*(S試験|Q試験)?\s*(.+)"
    events = []
    year = datetime.datetime.now().year
    for line in text.split("\n"):
        m = re.match(pattern, line)
        if m:
            month_day, grade, course, subcourse, exam_type, title = m.groups()
            grade = grade or ""
            course = course or ""
            subcourse = subcourse or ""
            exam_type = exam_type or ""
            # 必要条件に合致するか
            if (
                (not selected_grade or selected_grade in grade)
                and (not selected_course or selected_course in course)
                and (
                    not selected_subcourse
                    or selected_subcourse in subcourse
                )
                and (
                    not selected_exam_type
                    or selected_exam_type in exam_type
                )
            ):
                try:
                    date = datetime.datetime.strptime(f"{year}/{month_day}", "%Y/%m/%d")
                    events.append({"date": date, "title": title})
                except ValueError:
                    continue
    return events

def filter_holidays(events):
    return [e for e in events if not jpholiday.is_holiday(e["date"])]

def get_calendar_service():
    SCOPES = ['https://www.googleapis.com/auth/calendar']
    flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
    creds = flow.run_local_server(port=0)
    service = build('calendar', 'v3', credentials=creds)
    return service

def add_events_to_calendar(events, service, calendar_id='primary'):
    for event in events:
        body = {
            'summary': event['title'],
            'start': {'date': event['date'].strftime('%Y-%m-%d')},
            'end': {'date': event['date'].strftime('%Y-%m-%d')},
        }
        service.events().insert(calendarId=calendar_id, body=body).execute()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        grade = request.form.get('grade')
        course = request.form.get('course')
        subcourse = request.form.get('subcourse', None)
        exam_type = request.form.get('exam_type')
        file = request.files['image']
        with tempfile.NamedTemporaryFile(delete=False, dir=UPLOAD_FOLDER, suffix='.jpg') as tmp:
            file_path = tmp.name
            file.save(file_path)
        text = extract_text(file_path)
        events = parse_events(text, grade, course, subcourse, exam_type)
        events = filter_holidays(events)
        session['events'] = [
            {
                "date": e["date"].strftime('%Y-%m-%d'),
                "title": e["title"]
            } for e in events
        ]
        # 明示的にファイル削除
        os.remove(file_path)
        return render_template('confirm.html', events=events)
    return render_template('index.html')

@app.route('/add_to_calendar', methods=['POST'])
def add_to_calendar():
    events = session.get('events', [])
    # datetime型に戻す
    event_objs = []
    for e in events:
        try:
            event_objs.append({
                "date": datetime.datetime.strptime(e["date"], '%Y-%m-%d'),
                "title": e["title"]
            })
        except:
            continue
    service = get_calendar_service()
    add_events_to_calendar(event_objs, service)
    return "Googleカレンダーに追加しました！"

if __name__ == "__main__":
    app.run(debug=True)